// ---------- Service selection ----------
const serviceGrid = document.getElementById('serviceGrid');
const detailName = document.getElementById('detailName');
const detailDesc = document.getElementById('detailDesc');
const detailPrice = document.getElementById('detailPrice');
const detailDuration = document.getElementById('detailDuration');

const serviceInfo = {
  corte: { desc: 'Estilo y personalidad en cada corte. Incluye asesoría personalizada.', duration: '60 minutos' },
  peinado: { desc: 'Peinados para toda ocasión, adaptados a tu estilo.', duration: '45 minutos' },
  coloracion: { desc: 'Color a la medida con productos de alta calidad.', duration: '90 minutos' },
  tratamientos: { desc: 'Nutrición e hidratación profunda para tu cabello.', duration: '50 minutos' },
  afeitado: { desc: 'Afeitado clásico con toalla caliente y acabado preciso.', duration: '30 minutos' },
  manicura: { desc: 'Cuidado completo de manos y uñas.', duration: '40 minutos' },
};

serviceGrid.addEventListener('click', (e) => {
  const card = e.target.closest('.service-card');
  if (!card) return;

  serviceGrid.querySelectorAll('.service-card').forEach((c) => c.classList.remove('service-card--selected'));
  card.classList.add('service-card--selected');

  const key = card.dataset.service;
  const info = serviceInfo[key] || {};
  detailName.textContent = card.dataset.name;
  detailPrice.textContent = `$${card.dataset.price}`;
  detailDesc.textContent = info.desc || '';
  detailDuration.textContent = info.duration || '';
});

// ---------- Calendar ----------
const calendarMonth = document.getElementById('calendarMonth');
const calendarDays = document.getElementById('calendarDays');
const prevMonthBtn = document.getElementById('prevMonth');
const nextMonthBtn = document.getElementById('nextMonth');

const monthNames = [
  'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
  'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre',
];

// Start on April 2025 to match the reference design, with the 15th preselected
let viewYear = 2025;
let viewMonth = 3; // 0-indexed -> April
let selectedDate = { year: 2025, month: 3, day: 15 };

function renderCalendar() {
  calendarMonth.textContent = `${monthNames[viewMonth]} ${viewYear}`;
  calendarDays.innerHTML = '';

  const firstDay = new Date(viewYear, viewMonth, 1);
  // Convert Sunday(0)-Saturday(6) to Monday-first index
  const startOffset = (firstDay.getDay() + 6) % 7;

  const daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate();
  const daysInPrevMonth = new Date(viewYear, viewMonth, 0).getDate();

  // Leading days from previous month
  for (let i = startOffset; i > 0; i--) {
    calendarDays.appendChild(makeDayCell(daysInPrevMonth - i + 1, true));
  }

  // Days of current month
  for (let day = 1; day <= daysInMonth; day++) {
    const isSelected =
      selectedDate.year === viewYear && selectedDate.month === viewMonth && selectedDate.day === day;
    calendarDays.appendChild(makeDayCell(day, false, isSelected));
  }

  // Trailing days to fill the last week
  const totalCells = startOffset + daysInMonth;
  const trailing = (7 - (totalCells % 7)) % 7;
  for (let day = 1; day <= trailing; day++) {
    calendarDays.appendChild(makeDayCell(day, true));
  }
}

function makeDayCell(day, muted, selected) {
  const btn = document.createElement('button');
  btn.type = 'button';
  btn.textContent = day;
  btn.className = 'day-cell' + (muted ? ' day-cell--muted' : '') + (selected ? ' day-cell--selected' : '');

  if (!muted) {
    btn.addEventListener('click', () => {
      selectedDate = { year: viewYear, month: viewMonth, day };
      renderCalendar();
    });
  }
  return btn;
}

prevMonthBtn.addEventListener('click', () => {
  viewMonth -= 1;
  if (viewMonth < 0) {
    viewMonth = 11;
    viewYear -= 1;
  }
  renderCalendar();
});

nextMonthBtn.addEventListener('click', () => {
  viewMonth += 1;
  if (viewMonth > 11) {
    viewMonth = 0;
    viewYear += 1;
  }
  renderCalendar();
});

renderCalendar();

// ---------- Time slots ----------
const timeGrid = document.getElementById('timeGrid');

timeGrid.addEventListener('click', (e) => {
  const slot = e.target.closest('.time-slot');
  if (!slot) return;

  timeGrid.querySelectorAll('.time-slot').forEach((s) => s.classList.remove('time-slot--selected'));
  slot.classList.add('time-slot--selected');
});

// ---------- Next button (placeholder navigation) ----------
document.getElementById('nextBtn').addEventListener('click', () => {
  document.querySelector('.datetime-layout')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
});